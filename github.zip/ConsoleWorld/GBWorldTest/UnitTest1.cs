﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace ConsoleWorldTest
{
    [TestClass]
    public class UnitTest1
    {

        private const string Excepted = "GoodBye World!";

        [TestMethod]
        public void TestMethod1()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                GBWorld.Program.Main();

                var result = sw.ToString().Trim();
                Assert.AreEqual(Excepted, result);
            }
        }
    }
}
