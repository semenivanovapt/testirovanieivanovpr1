﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleWorld
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Hello World!");
        }
}
}
