﻿namespace ConsoleWorldTest
{
    internal class Excepted
    {
    }
}