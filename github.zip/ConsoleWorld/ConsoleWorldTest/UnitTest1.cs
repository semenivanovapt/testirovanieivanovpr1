﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace ConsoleWorldTest
{
    [TestClass]
    public class UnitTest1
    {

        private const string Excepted = "Hello World!";

        [TestMethod]
        public void TestMethod1()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                ConsoleWorld.Program.Main();

                var result = sw.ToString().Trim();
                Assert.AreEqual(Excepted, result);
            }
        }

        private const string Ozid = "GoodBye World!";

        [TestMethod]
        public void TestMethod2()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                GBWorld.Program.Main();

                var result = sw.ToString().Trim();
                Assert.AreEqual(Ozid, result);
            }
        }
    }
}
